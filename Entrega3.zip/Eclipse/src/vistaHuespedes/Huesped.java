package vistaHuespedes;

public class Huesped {
	
	String usuario;
	String clave;
	
	public Huesped(String usuario,String clave)
	{
		this.usuario = usuario;
		this.clave = clave;
	}
	
	public String getUser()
	{
		return usuario;
	}
	
	public String getClave()
	{
		return clave;
	}
}
