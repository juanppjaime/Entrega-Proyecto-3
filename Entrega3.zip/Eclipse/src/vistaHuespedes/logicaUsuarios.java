package vistaHuespedes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import Logica.Usuario;

public class logicaUsuarios {
	
	private ArrayList<Huesped> huespedes = new ArrayList<>();
	
	public void cargarArchivos() throws IOException, ParseException {
		this.cargarHuespedes();
	}
	
public void cargarHuespedes() throws IOException {
		
		FileReader file = new FileReader("./data/usuariohuespedes.txt");
		BufferedReader br = new BufferedReader(file);

		String linea = br.readLine();

		while (linea != null) {
			
			String[] partes = linea.split(";");
			
			String usuario = partes[0];
			String clave = partes[1];
			
			 Huesped huesped = new Huesped(usuario,clave);
			
			huespedes.add(huesped);
			
			linea = br.readLine(); //Salto de linea

		}

		br.close();
		

}

public Huesped validarHuesped(String usuario, String clave) {
	
	Huesped huesped=null;
	
	for(int i=0;i<huespedes.size();i++) {
		
		if(huespedes.get(i).getUser().equals(usuario)&&huespedes.get(i).getClave().equals(clave)) {
			huesped= huespedes.get(i);
		}
	}
	
	return huesped;
	
}



}