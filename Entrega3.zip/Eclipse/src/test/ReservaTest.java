package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Reserva;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReservaTest {

    @Test
    public void testGetIdHabitacion() throws ParseException {
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals(101, reserva.getIdHabitacion());
    }

    @Test
    public void testGetFechaInicio() throws ParseException {
        Date expectedDate = new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2023");
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals(expectedDate, reserva.getFechaInicio());
    }

    @Test
    public void testGetFechaFin() throws ParseException {
        Date expectedDate = new SimpleDateFormat("dd/MM/yyyy").parse("18/12/2023");
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals(expectedDate, reserva.getFechaFin());
    }

    @Test
    public void testGetFechaInicioString() throws ParseException {
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals("12/12/2023", reserva.getFechaInicioString());
    }

    @Test
    public void testGetFechaFinString() throws ParseException {
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals("18/12/2023", reserva.getFechaFinString());
    }

    @Test
    public void testGetIdReserva() throws ParseException {
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals(1, reserva.getIdReserva());
    }

    @Test
    public void testGetNombreCliente() throws ParseException {
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals("Juan Perez", reserva.getNombreCliente());
    }

    @Test
    public void testGetPrecio() throws ParseException {
        Reserva reserva = new Reserva(1, 101, "12/12/2023", "18/12/2023", 1, "Juan Perez", 1000.0);
        Assertions.assertEquals(1000.0, reserva.getPrecio());
    }
}