package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Cama;
import Logica.Habitacion;

import java.util.ArrayList;

public class HabitacionTest {

    @Test
    public void testGetIdentificador() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertEquals(1, habitacion.getIdentificador());
    }

    @Test
    public void testGetUbicacion() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertEquals("Planta baja", habitacion.getUbicacion());
    }

    @Test
    public void testIsBalcon() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertFalse(habitacion.isBalcon());
    }

    @Test
    public void testIsVista() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertTrue(habitacion.isVista());
    }

    @Test
    public void testIsCocina() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertTrue(habitacion.isCocina());
    }

    @Test
    public void testGetCamas() {
        ArrayList<Cama> camas = new ArrayList<>();
        camas.add(new Cama("Individual", 0, 1));
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                camas, "Individual");
        Assertions.assertEquals(camas, habitacion.getCamas());
    }

    @Test
    public void testGetTipo() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertEquals("Individual", habitacion.getTipo());
    }

    @Test
    public void testToString() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        String expectedString = "1;Planta baja;false;true;true;mediana;Individual";
        Assertions.assertEquals(expectedString, habitacion.toString());
    }

    @Test
    public void testCapacidadNinos() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertEquals(3, habitacion.capacidadNinos());
    }

    @Test
    public void testCapacidadAdultos() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertEquals(2, habitacion.capacidadAdultos());
    }

    @Test
    public void testCapacidad() {
        Habitacion habitacion = new Habitacion(1, "Planta baja", false, true, true,
                new ArrayList<>(), "Individual");
        Assertions.assertEquals(5, habitacion.capacidad());
    }
}
