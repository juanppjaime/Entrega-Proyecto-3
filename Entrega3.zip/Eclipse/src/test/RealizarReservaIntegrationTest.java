package test;

import Logica.Habitacion;
import Logica.Hotel;
import Vista.RealizarReserva;

import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

public class RealizarReservaIntegrationTest {
    @Test
    public void testRealizarReserva() {
        // Crear una instancia de la clase RealizarReserva
        RealizarReserva realizarReserva = new RealizarReserva();

        // Configurar los valores de entrada para la reserva
        realizarReserva.txtIngreso.setText("01/06/2023");
        realizarReserva.txtSalida.setText("05/06/2023");
        realizarReserva.txtCodigo.setText("301");
        realizarReserva.txtHuesped.setText("John Doe");
        realizarReserva.txtDocumento.setText("123456789");
        realizarReserva.txtCorreo.setText("john.doe@example.com");
        realizarReserva.txtTelefono.setText("1234567890");

        // Verificar los resultados esperados
        // Aquí puedes agregar las aserciones necesarias para verificar la lógica de negocio

        // Ejemplo de aserción: Verificar que la reserva se haya realizado correctamente
        Hotel hotel = new Hotel();
        try {
            ArrayList<Habitacion> habitacionesDisponibles = hotel.habitacionesPorFecha("01/06/2023", "05/06/2023");
            boolean habitacionEncontrada = false;
            for (Habitacion habitacion : habitacionesDisponibles) {
                if (habitacion.getIdentificador() == 301) {
                    habitacionEncontrada = true;
                    break;
                }
            }
            Assert.assertTrue("La habitación debería estar disponible en esas fechas", habitacionEncontrada);
        } catch (ParseException | IOException e) {
            e.printStackTrace();
            Assert.fail("Error al obtener las habitaciones disponibles");
        }
    }
    
    @Test
    public void testLimpiar() {
        // Crear una instancia de la clase RealizarReserva
        RealizarReserva realizarReserva = new RealizarReserva();

        // Configurar valores en los campos de texto
        realizarReserva.txtCodigo.setText("123");
        realizarReserva.txtIngreso.setText("01/06/2023");
        realizarReserva.txtSalida.setText("05/06/2023");
        realizarReserva.txtHuesped.setText("John Doe");
        realizarReserva.txtDocumento.setText("123456789");
        realizarReserva.txtCorreo.setText("john.doe@example.com");
        realizarReserva.txtTelefono.setText("1234567890");
        realizarReserva.txtCantidad.setText("2");

        // Llamar al método limpiar()
        realizarReserva.limpiar();

        // Verificar que los campos de texto estén vacíos
        Assert.assertEquals("", realizarReserva.txtCodigo.getText());
        Assert.assertEquals("", realizarReserva.txtIngreso.getText());
        Assert.assertEquals("", realizarReserva.txtSalida.getText());
        Assert.assertEquals("", realizarReserva.txtHuesped.getText());
        Assert.assertEquals("", realizarReserva.txtDocumento.getText());
        Assert.assertEquals("", realizarReserva.txtCorreo.getText());
        Assert.assertEquals("", realizarReserva.txtTelefono.getText());
        Assert.assertEquals("", realizarReserva.txtCantidad.getText());
    }
}

