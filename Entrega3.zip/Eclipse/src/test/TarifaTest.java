package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Tarifa;

import java.util.Date;

public class TarifaTest {

    @Test
    public void testGetters() {
        // Crear objetos de prueba
        String tipoHabitacion = "Doble";
        Date fechaInicial = new Date();
        Date fechaFinal = new Date();
        String[] dias = {"Lunes", "Martes", "Miércoles"};
        double precio = 100.0;

        Tarifa tarifa = new Tarifa(tipoHabitacion, fechaInicial, fechaFinal, dias, precio);

        // Verificar los valores obtenidos a través de los getters
        Assertions.assertEquals(tipoHabitacion, tarifa.getTipoHabitacion());
        Assertions.assertEquals(fechaInicial, tarifa.getFechaInicial());
        Assertions.assertEquals(fechaFinal, tarifa.getFechaFinal());
        Assertions.assertArrayEquals(dias, tarifa.getDias());
        Assertions.assertEquals(precio, tarifa.getPrecio());
    }
}