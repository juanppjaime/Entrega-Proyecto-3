package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Factura;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

public class FacturaTest {

    @Test
    public void testImprimirFacturaEnPantalla() {
        Factura factura = new Factura(1, 1, "Mensaje de prueba");
        
        // Redireccionar la salida estándar a un ByteArrayOutputStream
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        factura.imprimirFacturaEnPantalla();

        // Capturar la salida estándar en una variable String
        String output = outputStream.toString();

        // Restaurar la salida estándar
        System.setOut(System.out);

        Assertions.assertEquals("Mensaje de prueba\n", output);
    }

    @Test
    public void testGuardarFactura() throws IOException {
        Factura factura = new Factura(1, 1, "Mensaje de prueba");
        factura.guardarFactura();

        String expectedMessage = "Mensaje de prueba";
        String actualMessage;

        // Leer el contenido del archivo generado
        try (BufferedReader reader = new BufferedReader(new FileReader("./facturas/Factura_1.txt"))) {
            actualMessage = reader.readLine();
        }

        Assertions.assertEquals(expectedMessage, actualMessage);
    }
}