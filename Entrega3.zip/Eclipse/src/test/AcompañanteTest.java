package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Acompañante;

public class AcompañanteTest {

    @Test
    public void testGetNombre() {
        Acompañante acompañante = new Acompañante(1, 1001, "Juan", "1234567890");
        Assertions.assertEquals("Juan", acompañante.getNombre());
    }

    @Test
    public void testGetDocumento() {
        Acompañante acompañante = new Acompañante(1, 1001, "Juan", "1234567890");
        Assertions.assertEquals("1234567890", acompañante.getDocumento());
    }
    
    @Test
    public void testGetIdReserva() {
        Acompañante acompañante = new Acompañante(1, 1001, "Juan", "1234567890");
        Assertions.assertEquals(1, acompañante.getIdReserva());
    }
}