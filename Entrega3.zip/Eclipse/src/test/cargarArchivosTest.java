package test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import Logica.Hotel;

import java.io.IOException;
import java.text.ParseException;

public class cargarArchivosTest {

    @Test
    public void cargarArchivosTest() throws IOException, ParseException {
        Hotel hotel = new Hotel();

        try {
            hotel.cargarArchivos();
        } catch (IOException | ParseException e) {
            Assertions.fail("Se produjo una excepción: " + e.getMessage());
        }

        // Comprobar que las listas se hayan cargado correctamente
        Assertions.assertNotNull(hotel.getServicios());
        Assertions.assertNotNull(hotel.getInventario());
        Assertions.assertNotNull(hotel.getReservas());
    }
}
