package Vista;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PasarelasPanel extends JPanel {

    private List<String> pasarelas;

    public PasarelasPanel() {
        pasarelas = cargarPasarelasDesdeArchivo();
        crearBotonesPasarelas();
    }

    private List<String> cargarPasarelasDesdeArchivo() {
        List<String> pasarelas = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("./data/pasarelas.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                pasarelas.add(linea.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return pasarelas;
    }

    private void crearBotonesPasarelas() {
    	
    	JLabel lblTitulo = new JLabel("SELECIONE SU MÉTODO DE PAGO:");
    	lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
    	//lblTitulo.setFont(lblTitulo.getFont().deriveFont(Font.BOLD).deriveFont(Font.UPPERCASE));
    	add(lblTitulo);
    	setLayout(new GridLayout(pasarelas.size() + 1, 1));
        for (String pasarela : pasarelas) {
            JButton btnPasarela = new JButton(pasarela);
            
            // Establecer el color de fondo azul
            btnPasarela.setBackground(Color.BLUE);
            
            // Establecer el color de letra blanco
            btnPasarela.setForeground(Color.WHITE);
            
            btnPasarela.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "Ha seleccionado pago con " + pasarela);
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("./data/PagosTarjeta.txt", true))) {
                        writer.write(pasarela);
                        writer.write(";");
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    JFrame frame = new JFrame();
                    JPanel panel = new DatosPagoPanel(pasarela);
                    frame.add(panel);
                    frame.setSize(500, 500);
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);
                    SwingUtilities.getWindowAncestor(PasarelasPanel.this).dispose();
                }
            });
            add(btnPasarela);
        }
    }

}


