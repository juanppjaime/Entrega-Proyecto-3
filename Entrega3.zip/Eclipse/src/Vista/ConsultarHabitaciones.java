package Vista;

import java.awt.Font;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Logica.Habitacion;
import Logica.Hotel;

public class ConsultarHabitaciones extends JPanel {
	
	private JTable tablaHabitaciones;
	private DefaultTableModel model;
	
	public ConsultarHabitaciones() throws IOException {
		setLayout(null);
		
		JLabel lblListaDeHabitaciones = new JLabel("Lista de Habitaciones:");
		lblListaDeHabitaciones.setBounds(46, 30, 716, 22);
		lblListaDeHabitaciones.setFont(new Font("Tahoma", Font.BOLD, 18));
		add(lblListaDeHabitaciones);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(46, 112,791, 385);
		add(scrollPane);
		
		tablaHabitaciones = new JTable();
		scrollPane.setViewportView(tablaHabitaciones);
		
		model = new DefaultTableModel();
		String[] columnas = {"Código","Ubicación","Balcon","Vista","Cocina","C_Niños","C_Adultos","Tipo","M^2","Aire","Calefaccion","TV","Cafetera","Tapetes","Plancha","Secador","VoltajeAC","USB-A","USB-B","Desayuno"};
		model.setColumnIdentifiers(columnas);
		this.llenarTabla();
		tablaHabitaciones.setModel(model);
		
		JLabel lblNewLabel = new JLabel("Caracteristicas: Piscina - Zonas Húmedas - Wifi Gratis - Admite mascotas - Parqueadero de pago");
		lblNewLabel.setBounds(56, 62, 477, 13);
		add(lblNewLabel);

	}
	
	private void llenarTabla() throws IOException {
		Hotel hotel = new Hotel();
		ArrayList<Habitacion> habitaciones = hotel.getInventario();
		
		for(int i=0;i<habitaciones.size();i++) {
			
			Object[] fila = new Object[20];
			fila[0] =habitaciones.get(i).getIdentificador();
			fila[1] = habitaciones.get(i).getUbicacion();
			fila[2] =habitaciones.get(i).isBalcon();
			fila[3] = habitaciones.get(i).isCocina();
			fila[4] = habitaciones.get(i).isVista();
			fila[5]= habitaciones.get(i).capacidadNinos();
			fila[6]=habitaciones.get(i).capacidadAdultos();
			fila[7]=habitaciones.get(i).getTipo();
			fila[8]=habitaciones.get(i).getMetrosCuadrados();
			fila[9]=habitaciones.get(i).isAireAcondicionado();
			fila[10]=habitaciones.get(i).isCalefaccion();
			fila[11]=habitaciones.get(i).isTV();
			fila[12]=habitaciones.get(i).isCafetera();
			fila[13]=habitaciones.get(i).isTapetesHipo();
			fila[14]=habitaciones.get(i).isPlancha();
			fila[15]=habitaciones.get(i).isSecador();
			fila[16]=habitaciones.get(i).isVoltajeAC();
			fila[17]=habitaciones.get(i).isUSBA();
			fila[18]=habitaciones.get(i).isUSBC();
			fila[19]=habitaciones.get(i).isDesayuno();
			
			model.addRow(fila);
		}
	}
}
