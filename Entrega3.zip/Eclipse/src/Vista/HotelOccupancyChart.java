package Vista;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.JPanel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class HotelOccupancyChart {
    public static JPanel createChartPanel() {
        // Ruta del archivo "reservas.txt"
        String filePath = "data/reservas.txt";

        // Crear un mapa para almacenar la cantidad de reservas por mes
        Map<Integer, Integer> monthlyOccupancy = new HashMap<>();

        // Leer el archivo y procesar los datos
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] reservaData = line.split(";");
                if (reservaData.length >= 4) {
                    String fechaInicioStr = reservaData[2];
                    int month = extractMonthFromDate(fechaInicioStr);
                    monthlyOccupancy.put(month, monthlyOccupancy.getOrDefault(month, 0) + 1);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear el conjunto de datos para el gráfico
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<Integer, Integer> entry : monthlyOccupancy.entrySet()) {
            int month = entry.getKey();
            int occupancy = entry.getValue();
            String monthName = new DateFormatSymbols().getMonths()[month - 1];
            dataset.addValue(occupancy, "Ocupación", monthName);
        }

        // Crear el gráfico de barras
        JFreeChart chart = ChartFactory.createBarChart(
                "Ocupación Mensual del Hotel",
                "Meses",
                "Cantidad de Reservas",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        // Crear el panel del gráfico y retornarlo
        ChartPanel chartPanel = new ChartPanel(chart);
        return chartPanel;
    }

    private static int extractMonthFromDate(String dateString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date date = dateFormat.parse(dateString);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            return calendar.get(Calendar.MONTH) + 1; // Los meses en Calendar comienzan en 0, por eso se suma 1
        } catch (ParseException e) {
            e.printStackTrace();
            return -1; // Error al analizar la fecha
        }
    }
}
