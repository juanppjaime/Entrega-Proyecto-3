package Vista;

import javax.swing.JOptionPane;

public class Sire implements PasarelaPago {
    public boolean realizarPago(double monto, String numeroCuenta) {
       
    	JOptionPane.showMessageDialog(null,"Pago realizado con éxito a través de Sire");
        return true;
    }
}
