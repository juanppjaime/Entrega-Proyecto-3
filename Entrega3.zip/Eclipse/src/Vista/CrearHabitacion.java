package Vista;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;

import Logica.Hotel;
import javax.swing.LayoutStyle.ComponentPlacement;

public class CrearHabitacion extends JPanel {

	private JTextField txtID;
	private JTextField txtUbicacion;
	private JComboBox comboBalcon;
	private JComboBox comboVista;
	private JComboBox comboCama;
	private JComboBox comboCocina;
	private JComboBox comboTipo;
	private JTextField txtMetros;
	private JComboBox txtAire;
	private JComboBox txtTV;
	private JComboBox txtTapetes;
	private JComboBox txtPlancha;
	private JComboBox txtCafetera;
	private JComboBox txtSecador;
	private JComboBox txtVoltaje;
	private JComboBox txtUSBA;
	private JComboBox txtUSBB;
	private JComboBox txtDesayuno;
	private JComboBox txtCale;
	
	
	
	public CrearHabitacion() {
		
setBackground(Color.WHITE);
		
		JLabel Id = new JLabel("Id:");
		Id.setBounds(55, 58, 46, 14);
		Id.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		txtID = new JTextField();
		txtID.setBounds(83, 52, 100, 25);
		txtID.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtID.setColumns(10);
		
		JLabel lblBalcn = new JLabel("Balcón:");
		lblBalcn.setBounds(24, 115, 60, 14);
		lblBalcn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblVista = new JLabel("Vista:");
		lblVista.setBounds(24, 173, 60, 14);
		lblVista.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblTipoCama = new JLabel("Cama:");
		lblTipoCama.setBounds(24, 213, 60, 14);
		lblTipoCama.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblUbicacin = new JLabel("Ubicación:");
		lblUbicacin.setBounds(214, 57, 86, 14);
		lblUbicacin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		txtUbicacion = new JTextField();
		txtUbicacion.setBounds(299, 52, 192, 25);
		txtUbicacion.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUbicacion.setColumns(10);
		
		JLabel lblCocina = new JLabel("Cocina:");
		lblCocina.setBounds(242, 115, 60, 14);
		lblCocina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JLabel lblCantidad = new JLabel("Tipo:");
		lblCantidad.setBounds(296, 240, 60, 14);
		lblCantidad.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		 comboBalcon = new JComboBox();
		 comboBalcon.setBounds(83, 115, 100, 22);
		comboBalcon.setModel(new DefaultComboBoxModel(new String[] {"", "SI", "NO"}));
		
		comboVista = new JComboBox();
		comboVista.setBounds(83, 171, 100, 19);
		comboVista.setModel(new DefaultComboBoxModel(new String[] {"", "SI", "NO"}));
		
		comboCocina = new JComboBox();
		comboCocina.setBounds(299, 113, 100, 19);
		comboCocina.setModel(new DefaultComboBoxModel(new String[] {"", "SI", "NO"}));
		
		comboCama = new JComboBox();
		comboCama.setBounds(88, 213, 100, 19);
		comboCama.setModel(new DefaultComboBoxModel(new String[] {"", "pequeña", "media", "grande", "queen", "king"}));
		
		JButton btnNewButton = new JButton("Guardar Habitación");
		btnNewButton.setBounds(119, 472, 184, 23);
		comboTipo = new JComboBox();
		comboTipo.setBounds(299, 239, 100, 20);
		btnNewButton.setBackground(Color.GREEN);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(txtUbicacion.getText().isEmpty()||txtID.getText().isEmpty() || comboTipo.getSelectedIndex()==0
						|| comboBalcon.getSelectedIndex()==0 || comboVista.getSelectedIndex()==0 || comboCocina.getSelectedIndex()==0
						|| comboCama.getSelectedIndex()==0) {
					JOptionPane.showMessageDialog(null, "Debe rellenar todos los campos");
					
				}else {
					boolean balcon = false;
					boolean vista=false;
					boolean cocina=false;
					
					
					if(comboBalcon.getSelectedItem().toString().equals("SI")) {
						balcon=true;
					}
					if(comboVista.getSelectedItem().toString().equals("SI")) {
						vista=true;
					}
					if(comboCocina.getSelectedItem().toString().equals("SI")) {
						cocina=true;
					}
					
					int metros = Integer.parseInt(txtMetros.getText());
					boolean calefaccion = Boolean.parseBoolean(txtCale.getSelectedItem().toString());
					boolean TV = Boolean.parseBoolean(txtTV.getSelectedItem().toString());
					boolean cafetera = Boolean.parseBoolean(txtCafetera.getSelectedItem().toString());
					boolean tapete = Boolean.parseBoolean(txtTapetes.getSelectedItem().toString());
					boolean plancha = Boolean.parseBoolean(txtPlancha.getSelectedItem().toString());
					boolean secador = Boolean.parseBoolean(txtSecador.getSelectedItem().toString());
					boolean voltaje = Boolean.parseBoolean(txtVoltaje.getSelectedItem().toString());
					boolean usbA = Boolean.parseBoolean(txtUSBA.getSelectedItem().toString());
					boolean usbB = Boolean.parseBoolean(txtUSBB.getSelectedItem().toString());
					boolean desayuno = Boolean.parseBoolean(txtDesayuno.getSelectedItem().toString());
					boolean aire = Boolean.parseBoolean(txtAire.getSelectedItem().toString());
					
					

					
					Hotel hotel = new Hotel();
					try {
						hotel.guardarHabitacion(Integer.valueOf(txtID.getText()), txtUbicacion.getText(), balcon, vista, cocina, comboCama.getSelectedItem().toString(),comboTipo.getSelectedItem().toString());;
						JOptionPane.showMessageDialog(null, "Habitación guardada");
						limpiar();
					} catch (NumberFormatException | IOException e1) {
						
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Ocurrio un error al guardar la habitacion revisa que los datos esten bien");
					}
					
				}
			}
		});
		
		
		comboTipo.setModel(new DefaultComboBoxModel(new String[] {"", "estandar", "suite", "suite doble"}));
		
		JButton btnLimpiarCampos = new JButton("Limpiar Campos");
		btnLimpiarCampos.setBounds(119, 505, 184, 23);
		btnLimpiarCampos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiar();
			}
		});
		btnLimpiarCampos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimpiarCampos.setForeground(Color.WHITE);
		btnLimpiarCampos.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnLimpiarCampos.setBackground(Color.BLUE);
		
		JLabel lblTipoCama_1 = new JLabel("Calefaccion:");
		lblTipoCama_1.setBounds(0, 295, 84, 14);
		lblTipoCama_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JComboBox txtCale = new JComboBox();
		txtCale.setBounds(88, 295, 100, 19);
		setLayout(null);
		add(txtID);
		add(Id);
		add(lblUbicacin);
		add(txtUbicacion);
		add(lblVista);
		add(comboVista);
		add(btnNewButton);
		add(btnLimpiarCampos);
		add(lblTipoCama);
		add(comboCama);
		add(comboBalcon);
		add(lblBalcn);
		add(lblCocina);
		add(comboTipo);
		add(comboCocina);
		add(lblCantidad);
		add(lblTipoCama_1);
		add(txtCale);
		
		JLabel lblAireAcondicionado = new JLabel("Aire Acondicionado:");
		lblAireAcondicionado.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAireAcondicionado.setBounds(9, 253, 100, 14);
		add(lblAireAcondicionado);
		
		JComboBox txtAire = new JComboBox();
		txtAire.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtAire.setBounds(119, 253, 100, 19);
		add(txtAire);
		
		JLabel lblTv = new JLabel("TV:");
		lblTv.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTv.setBounds(24, 335, 60, 14);
		add(lblTv);
		
		JComboBox txtTV = new JComboBox();
		txtTV.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtTV.setBounds(88, 335, 100, 19);
		add(txtTV);
		
		JLabel lblTapetes = new JLabel("Tapetes:");
		lblTapetes.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTapetes.setBounds(235, 295, 60, 14);
		add(lblTapetes);
		
		JComboBox txtTapetes = new JComboBox();
		txtTapetes.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtTapetes.setBounds(299, 295, 100, 19);
		add(txtTapetes);
		
		JLabel lblPlancha = new JLabel("Plancha:");
		lblPlancha.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPlancha.setBounds(235, 330, 60, 14);
		add(lblPlancha);
		
		JComboBox txtPlancha = new JComboBox();
		txtPlancha.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtPlancha.setBounds(299, 330, 100, 19);
		add(txtPlancha);
		
		JLabel lblCafetera = new JLabel("Cafetera:");
		lblCafetera.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCafetera.setBounds(20, 380, 84, 14);
		add(lblCafetera);
		
		JComboBox txtCafetera = new JComboBox();
		txtCafetera.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtCafetera.setBounds(108, 380, 100, 19);
		add(txtCafetera);
		
		JLabel lblSecador = new JLabel("Secador:");
		lblSecador.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblSecador.setBounds(242, 380, 60, 14);
		add(lblSecador);
		
		JComboBox txtSecador = new JComboBox();
		txtSecador.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtSecador.setBounds(306, 380, 100, 19);
		add(txtSecador);
		
		JLabel lblVoltajeac = new JLabel("VoltajeAC:");
		lblVoltajeac.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblVoltajeac.setBounds(20, 414, 84, 14);
		add(lblVoltajeac);
		
		JComboBox txtVoltaje = new JComboBox();
		txtVoltaje.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtVoltaje.setBounds(108, 414, 100, 19);
		add(txtVoltaje);
		
		JLabel lblUsba = new JLabel("USB-A:");
		lblUsba.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUsba.setBounds(218, 409, 84, 14);
		add(lblUsba);
		
		JComboBox txtUSBA = new JComboBox();
		txtUSBA.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtUSBA.setBounds(306, 409, 100, 19);
		add(txtUSBA);
		
		JLabel lblUsbb = new JLabel("USB-B:");
		lblUsbb.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUsbb.setBounds(20, 443, 84, 14);
		add(lblUsbb);
		
		JComboBox txtUSBB = new JComboBox();
		txtUSBB.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtUSBB.setBounds(108, 443, 100, 19);
		add(txtUSBB);
		
		JLabel lblDesayuno = new JLabel("Desayuno:");
		lblDesayuno.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDesayuno.setBounds(218, 443, 84, 14);
		add(lblDesayuno);
		
		JComboBox txtDesayuno = new JComboBox();
		txtDesayuno.setModel(new DefaultComboBoxModel(new String[] {"", "true", "false"}));
		txtDesayuno.setBounds(306, 443, 100, 19);
		add(txtDesayuno);
		
		JLabel lblM = new JLabel("M^2:");
		lblM.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblM.setBounds(235, 160, 60, 14);
		add(lblM);
		
		txtMetros = new JTextField();
		txtMetros.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtMetros.setColumns(10);
		txtMetros.setBounds(299, 162, 100, 25);
		add(txtMetros);

	}
	
	private void limpiar() {
		txtID.setText("");
		txtUbicacion.setText("");
		comboBalcon.setSelectedIndex(0);
		comboVista.setSelectedIndex(0);
		comboCocina.setSelectedIndex(0);
		comboCama.setSelectedIndex(0);
		comboTipo.setSelectedIndex(0);
		
	}
}
