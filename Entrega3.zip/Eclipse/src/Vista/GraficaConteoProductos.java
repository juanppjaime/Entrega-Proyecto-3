package Vista;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.JPanel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class GraficaConteoProductos {
    public static JPanel createChartPanel() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Leer el archivo serviciosRegistrados.txt y contar las ocurrencias de cada tipo de producto
        try (BufferedReader br = new BufferedReader(new FileReader("data/serviciosRegistrados.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(";");
                if (data.length == 3) {
                    String producto = data[1];
                    if (dataset.getColumnKeys().contains(producto)) {
                        dataset.incrementValue(1, "Conteo", producto);
                    } else {
                        dataset.addValue(1, "Conteo", producto);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear la gráfica de barras
        JFreeChart chart = ChartFactory.createBarChart(
                "Conteo de Productos Registrados",
                "Producto",
                "Cantidad",
                dataset
        );

        // Crear el panel del gráfico y retornarlo
        ChartPanel chartPanel = new ChartPanel(chart);
        return chartPanel;
    }
}

